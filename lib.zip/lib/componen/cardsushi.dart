import 'package:flutter/material.dart';

class cardSushi extends StatelessWidget {
  const cardSushi({
    super.key,
    required this.namaSushi,
    required this.jumlahPembelian,
    required this.tanggalPembelian,
  });
  final String namaSushi;
  final int jumlahPembelian;
  final String tanggalPembelian;
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        color: const Color.fromARGB(255, 135, 145, 121),
        height: 320,
        width: 200,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.food_bank,
                      size: 70,
                      color: Colors.black, //Nambah Ikon
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    '$namaSushi',
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Tanggal Beli: $tanggalPembelian",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
