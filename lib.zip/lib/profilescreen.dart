import 'package:flutter/material.dart';
import 'componen/cardsushi.dart';

class Profilescreen extends StatefulWidget {
  const Profilescreen({super.key, required this.username});
  final String username;
  @override
  State<Profilescreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<Profilescreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'PROFILE ${widget.username}',
          style: TextStyle(color: Colors.black),
        ),
        actions: [], //  Action
      ),
      body: ListView(
        children: [
          const SizedBox(height: 0),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            child: Center(
              child: Text(
                "Transaksi Sushi",
                style: TextStyle(color: Colors.black, fontSize: 25),
              ),
            ),
          ),
          cardSushi(
            namaSushi: "Nigiri",
            jumlahPembelian: 10,
            tanggalPembelian: "23/4/2024",
          ),
          cardSushi(
            namaSushi: "Sushi Roll",
            jumlahPembelian: 5,
            tanggalPembelian: "23/3/2023",
          ),
          cardSushi(
            namaSushi: "Sushi Gunkan",
            jumlahPembelian: 16,
            tanggalPembelian: "23/3/2022",
          ),
        ],
      ),
    );
  }
}
